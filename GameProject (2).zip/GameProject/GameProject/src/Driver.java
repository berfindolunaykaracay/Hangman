import StartPage.StartPage;

public class Driver {
	
	public static void main(String[] args) {
		
		System.out.println("WELCOME TO HANGMAN GAME");	
		StartPage page = new StartPage();
		page.setVisible(true);
		
	}
}
